define(['underscore','backbone','lib/config/config','lib/bootstrap/vendors/sweet-alert/sweet-alert.min','handlebars','jquery',/*'jqmobile',/*'jquery.mobiscroll','jqmobile.tabs',*/'yigo-mobile','yigo-mobilecontrol',
        'yigoview','yigo-vm','yigo-mobile-patch','bootstrap',
        'css!lib/bootstrap/vendors/sweet-alert/sweet-alert.min.css',
        'lib/mobiscroll/js/mobiscroll.custom-2.6.2.min',
        'lib/bootstrap-star-rating/js/star-rating.min',
		'css!lib/bootstrap-star-rating/css/star-rating.min.css',
        //'css!lib/jqmobile/jquery.mobile-1.4.2.css',
        //'css!lib/yigo/jquery.mobile.tabs.css',
        'css!lib/bootstrap/css/bootstrap.css',
        'css!lib/yigo/patchMobileFC.css',
        //'css!lib/mobiscroll/css/mobiscroll.custom-2.6.2.min.css',
        'css!lib/awesome/css/font-awesome.css'],function(_,Backbone,config,swal){
	YIGO.apply(YIGO, {
	    clone:function(v){
	    	return $.extend(true,{},v);
	    }
	});
	JSON.nativeStringify =  JSON.stringify;
	JSON.stringify = function(v){
		if(v.toJSON){
			return v.toJSON();
		}
		return JSON.nativeStringify(v);
	}
	YIGO.regDefaultConfig('map_dataview',{plugins:['grid-roweditor']});
//	YIGO.regDefaultConfig('map_billform',{plugins:['scrollbillform']});
//	YIGO_C_SERVER_URL="http://localhost:8080/yigo";
//	YIGO_C_SERVER_URL="http://10.0.2.2:8080/yigo";
	//YIGO_C_SERVER_URL="http://1.1.2.22:8099/Finance16";
	YIGO.ui.billLayouts={};
	var App = Backbone.Router.extend({
		logined:false,//是否已经完成登录
		forceLogin:true,//是否必须进行登录
		backbuttonProcessList:[],
		sessionKey:'yigomobile',
		loginPath:'yigo/LOGIN',//登录单据对应的路径
		homePath:'yigo/subsys_SCM_ToDoList',
		start:function(){
			YIGO_C_ENV.init();
			this.initLocalStorage();
		},
//		layoutTemplate:Handlebars.compile(pp),
		initialize:function(){
			this.route('yigo/:entry/:param','newyigo');
			this.route('yigo/:entry','yigo');
			this.route('slide/:entry','yigoslide');
			this.route('','home');
			this.route('navigator','navigator');
			this.on('route:yigoslide',this.onSlide,this);
			this.on('route:yigo',this.onOpenYIGOEntry,this);
			this.on('route:newyigo',this.onOpenNewYIGOEntry,this);
			this.on('route:home',this.onShowHome,this);
			this.on('route:navigator',this.onNavigator,this);
			this.on('inited',this.onInited,this);
//			this.route('rongyun/conversationlist','conversationlist');
//			this.route('rongyun/conversation/:receiver','conversation');
//			this.on('route:conversationlist',this.onOpenConversationList,this);
//			this.on('route:conversation',this.onOpenConversation,this);
			this.entryViews={};
//			$('body').append('<neon-animated-pages id="pages" class="flex" selected="[[selected]]" entry-animation="[[entryAnimation]]" exit-animation="[[exitAnimation]]">\
//			</neon-animated-pages>');
			this.pageContainer=$('body');
			this.initBillConfig(config);
//			this.initLocalStorage();
			this.on('contextclear',this.onContextClear,this);
			this.on('logined',this.onLogin,this);
			YIGO.ui.GlobalMessageBus.subscribe(YIGO.ui.Messages.LOGINSUCCESS,function(messageData){
//				if(!this.logined){
				this.logined = true;
				this.trigger('logined');
//				}
				if(this.forceLogin){
					this.navigate("",{trigger:true});
				}
			}.createDelegate(this));
//			YIGO.ui.GlobalMessageBus.subscribe(YIGO.ui.Messages.LOGINOUT,function(messageData){
//				YIGO.GlobalConversationMgr.logout();
//			}.createDelegate(this));
		    YIGO.ui.GlobalMessageBus.subscribe(YIGO.ui.Messages.ERROR,this.onError,this);
		    YIGO.ui.GlobalMessageBus.subscribe(YIGO.ui.Messages.LOGOUT,this.onLogout,this);
		    //截取页面上所有a标签的链接方式
//		    $(document).on('click','a[href^="yigo"]',function(e){
//		    	var url =$(e.target).attr('href');
//		    	this.navigate(url,{trigger:true});
//		    	e.preventDefault();
//		    }.createDelegate(this));
		    $(document).on('click','[data-yigobtn]',_.bind(function(e){
		    	var refDiv = $(event.target).closest("[data-yigobtn]");
		    	var optkey =refDiv.attr('data-yigobtn');
		    	e.preventDefault();
		    	if(this.currentView && this.currentView.yigoapp){
		    		_.delay(_.bind(this.currentView.yigoapp.activeContext.trigger,this.currentView.yigoapp.activeContext),300,'BUTTON_CLICK',optkey);
//		    		this.currentView.yigoapp.activeContext.trigger.('BUTTON_CLICK',optkey);
		    	}
		    	return false;
//		    	this.navigate(url,{trigger:true});
		    	//这里需要执行context中的指定操作
		    },this));
			$(document).on('click','[data-yigodismiss]',_.bind(function(e){
				var refDiv = $(event.target).closest(".modal");
				refDiv.modal('hide');
			},this));
			$(document).on('click','[data-yigomessage]',_.bind(function(e){
				var refDiv = $(event.target).closest("[data-yigomessage]");
				var message  = refDiv.attr('data-yigomessage');
				var param  = refDiv.attr('data-yigomessageparam');
				YIGO.ui.GlobalMessageBus.publish(message,[param]);
			},this));
		    $(document).on('click','[data-yigoopt]',_.bind(function(e){
		    	var refDiv = $(event.target).closest("[data-yigoopt]");
		    	var optkey =refDiv.attr('data-yigoopt');
		    	e.preventDefault();
		    	if(optkey=="uiclose"){
		    		this.currentView.closeview();
		    		return false;
		    	}
		    	if(this.currentView && this.currentView.yigoapp){
		    		var ctx = this.currentView.yigoapp.activeContext;
		    		if(ctx){
		    			YIGO.UIOptCenter.doUIOpt(ctx.getBillViewer().viewID,optkey,ctx.contextID);
		    		}
		    	}
		    	return false;
		    },this));
		    document.addEventListener("backbutton", _.bind(function(e){
		    	//::TODO这里需要支持弹出界面的处理，也就是如果有弹出界面则首先关闭弹出界面
		    	//当前需要考虑这个特殊处理的情况有如下几种：
		    	//1.dialoglayout
		    	//2.所有的弹出式的编辑界面
		    	e.preventDefault();
		    	if(this.beforeProcessBackButton()){
		    		return;
		    	}
		    	if(this.currentView && this.currentView.yigoapp && !this.currentView.isRootForm()){
		    		this.currentView.closeview();
		    		return;
		    	}
				if(this.currentView.param){
					this.currentView.closeview();
		    		return;
				}
		    	if(Backbone.history.getFragment()==this.homePath || 
		    			Backbone.history.getFragment()==this.loginPath){
		    		this.exit();
		    		return;	
		    	}
		    	history.back();
	        },this), false);
		    YIGO.ui.GlobalMessageBus.subscribe('historyback',function(){
		    	history.back();
		    },this);
		},
		beforeProcessBackButton:function(event){
			//预处理backbutton，这个函数返回true，会导致系统默认的backbutton的处理代码中之
			for(var i=0;i<this.backbuttonProcessList.length;i++){
				var fn = this.backbuttonProcessList[i];
				var result = fn();
				if(result){
					return true;
				}
			}
			return false;
		},
		exit:function(){
			swal({   
					title: "提示",   
					text: "确认退出系统?",   
					type: "info",   
					showCancelButton: true,   
					confirmButtonColor: "#DD6B55",   
					confirmButtonText: "退出",   
					cancelButtonText: "取消",
					closeOnConfirm: false }, 
					function(){   
						navigator.app.exitApp();
						});
		},
		beforeLogout:function(){},
		onLogout:function(){
			this.beforeLogout();
			this.logined=false;
			YIGO.UICache.clearAllCtxs();
			Object.keys(this.entryViews).each(function(item){
				var v = this.entryViews[item];
				v.remove();
			},this);
			this.entryViews = {};
			this.onShowHome();
		},
		onLogin:function(){
			
		},
		onError:function(messageData){
	        if (messageData.data.errorCode==10000003){ //登录超时
	        	this.navigate(this.loginPath,{trigger:true});
	        }
	        if (messageData.data.errorCode==10000004){ //单据超时
				YIGO.ui.GlobalMessageBus.publish(YIGO.ui.Messages.CLOSETAB, {
					context:messageData.context
				});
	        }
//	        var swal = require('lib/bootstrap/vendors/sweet-alert/sweet-alert.min');
	        if(this.inited){
	        	swal('警告',messageData.data.message||messageData.data,'error');
	        }else{
				swal({   
					title: "异常退出",   
					text: messageData.data.message||messageData.data,   
					type: "error",   
					confirmButtonColor: "#DD6B55",   
					confirmButtonText: "退出",   
					closeOnConfirm: false }, 
					function(){   
						navigator.app.exitApp();
						});
	        }
		},
		onContextClear:function(view){
			this.removeView(view);
			view.remove();
			//如果context是登陆界面的话，则不需要进行处理
			//如果是首页的话，则直接退出到登陆界面
			if(Backbone.history.getFragment()==this.homePath){
				YIGO.UIOptCenter.logout();
				return;
			}
			if(!this.forceLogin || view.rootBill!=YIGO.loginPageMetakey)
				history.back();
		},
		removeView:function(v){
			if(!v)
				return;
			if(this.entryViews[v.entry]){
				delete this.entryViews[v.entry];
			}
		},
		initBillConfig:function(cfg){
			if(cfg.appOption){
				_.extend(this,cfg.appOption);
			}
			if(this.serverPath){
				YIGO_C_SERVER_URL = this.serverPath;
			}
			if(cfg.routes){
				cfg.routes.each(function(route){
					this.route(route.pattern,route.name);
					this.on('route:' + route.name,route.fn,this);
				},this)
			}
			cfg.bills.each(function(bill){
				//bill.layoutType=bill.xtype || 'normallayout';
				var layout = YIGO.getMobileLayout(bill.layoutType || 'normallayout');
				if(layout){
					bill.layout = layout.render(bill);
					YIGO.ui.billLayouts[bill.metaKey] = {defaultLayout:bill};
				}
			},this)
		},
		onInited:function(){
			this.inited= true;
			Backbone.history.start();
		},
		initLocalStorage:function(){
			this.setting = localStorage.getItem('yigomobile-setting') || {};
			this.onSettingInited();
		},
		onSettingInited:function(){
			this.checkLoginStatus();
		},
		checkLoginStatus:function(){
			if(this.forceLogin){
				YIGO.ui.GlobalMessageBus.subscribeOnce("loginstatus",this.onLoginStatusChecked,this)
				YIGO.UIOptCenter.getLoginStatus();
			}else{
				this.trigger('inited');
			}
		},
		onLoginStatusChecked:function(data){
			this.logined = data.data.status;
			if(this.logined){
				YIGO.ui.GlobalMessageBus.publish(YIGO.ui.Messages.LOGINSUCCESS);
			}
			this.checkAutoLogin();
		},
		/**
		 * 系统的自动登陆功能其实是不存在的
		 */
		checkAutoLogin:function(){
			if(!this.logined && (this.setting.autoLogin && this.setting.user)){//满足了自动登录条件
				//需要自动登录，自动登录会打开一张登录单据，但是不显示
				//然后在后台完成整个登录过程，如果登录发生错误，则登录界面需要显示出来
			}else{
				this.trigger('inited');
			}
		},
		/**
		 * 生成一个slidePage,slidePage和正常的page的差异是层次高一点，
		 * 并且不占全屏幕，整个应用只能有一个slideView在显示中。
		 * slidePage不会影响当前的currentPage,
		 * 任何其他page的显示都会导致slideview的隐藏
		 * slidePage是系统中优先级最高的Page,当slidePage显示的时候
		 * android的回退操作会优先作用到它身上
		 */
		onSlide:function(entry){
			var view = this.entryViews[entry];
			if(!view)
				return;
			view.$el.addClass('slideshow');
			this.currentSlideView = view;
			this.showSlideShim();
		},
		hideSlide:function(){
			if(!this.currentSlideView)
				return;
			this.currentSlideView.$el.removeClass('slideshow');
			this.hideSlideShim();
			this.currentSlideView = null;
		},
		showSlideShim:function(){
			if(!this.slideShim){
				this.slideShim = $('<div class="slideshim"></div>')
				$('body').append(this.slideShim);
				this.slideShim.on('click',function(){
					this.hideSlide();
				}.createDelegate(this));
			}
			this.slideShim.show();
		},
		hideSlideShim:function(){
			if(this.slideShim)
				this.slideShim.hide();
		},
		/**
		 * 显示一个入口到一个指定的dom上，这个指定的dom可以位于任何位置
		 * 显示widget不会修改当前的currentPage
		 */
		onShowWidget:function(entry,target){
			
		},
		onOpenYIGOEntry:function(entry){
			var view = null;
			if(this.entryViews[entry]){
				view = this.entryViews[entry];
			}else{
				view = new Backbone.YigoView({app:this,entry:entry});
				this.appendView(view);
				this.entryViews[entry] = view;
				view.render();
			}
			this.changeView(view);
		},
		onOpenNewYIGOEntry:function(entry,param){
			var view = null;
			if(this.entryViews[entry]){
				view = this.entryViews[entry];
			}else{
				view = new Backbone.YigoView({app:this,entry:entry,param:param});
				this.appendView(view);
				this.entryViews[entry] = view;
			}
			view.render();
			this.changeView(view);
		},
		appendView:function(v){
			this.pageContainer.append(v.el);
		},
		changeView:function(view){
			if(view==this.currentView)
				return;
			this.hideSlide();
			view.show();
			if(this.currentView)
				this.currentView.hide()
			this.currentView = view;
		},
		onShowHome:function(){
			//如果已经登录则直接进入portal
			//如果没有登录则显示登录单据
			if(this.logined || !this.forceLogin){
				this.showPortalView();
			}else{
				this.navigate(this.loginPath,{trigger:true});
			}
		},
		showPortalView:function(){
			this.navigate(this.homePath,{trigger:true});
		}
	});
	return App;
});