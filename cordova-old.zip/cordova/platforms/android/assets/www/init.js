require.config({
	baseUrl:'js',
	paths: {
		'backbone':'lib/backbone/backbone',
		'backbone.localstorage':'lib/backbone/backbone.localStorage',
		'jquery':'lib/jquery/jquery-2.1.1',
		'backbone.scrollview':'lib/scrollview/backbone.scrollview',
		'yigoview':'lib/scrollview/backbone.yigoview',
		'yigo-mobile':'lib/yigo/YIGO-all-debug',
		'yigo-mobilecontrol':'lib/yigo/YIGO.ui.ControlMobileFC',
		'yigo-vm':'lib/yigo/YIGO.ui.ControlVM',
		'yigo-mobile-patch':'lib/yigo/YIGO.ui.mobile',
		'fastclick':'lib/fastclick',
		'hammerjs':'lib/hammer/hammer.min',
		'handlebars':'lib/handlebars',
		'iscroll':'lib/iscroll/iscroll-lite-5.1.2',
		'underscore':'lib/underscore',
		'bootstrap':'lib/bootstrap/js/bootstrap.min',
		'moment':'lib/moment/moment.min',
		'async':'async',
		'owl-carousel':'lib/owl-carousel/owl.carousel.min'
	},
	shim:{
		'underscore' : {
			exports:'_'
		},
		'bootstrap':{
			deps:['jquery']
		},
		'backbone' : {
			deps:['underscore','jquery'],
			exports:'Backbone'
		},
		'jquery.mobiscroll':{
			deps:['jquery']
		},
		'yigo-mobilecontrol':{
			deps:['yigo-mobile']
		},
		'yigo-vm':{
			deps:['yigo-mobile']
		},
		'owl-carousel':{
			deps:['jquery']
		}
	}
});

function onDeviceReady(){
	require(['jquery','underscore'],function(){
		var scrollToBottomOfView = function(){
			var activeElement = document.activeElement;
			if(activeElement){
				//这里需要做一下延迟
				var offset = activeElement.offsetTop-activeElement.offsetParent.offsetHeight + activeElement.offsetHeight;
				if(offset>0)
					activeElement.offsetParent.scrollTop=offset;
			}
		}
		document.addEventListener('showkeyboard',function(){
			_.delay(scrollToBottomOfView,500);
		},false);
		require(['App','fastclick'],function(app){
			//FastClick.attach(document.body);
			mobileapp = new app();
			mobileapp.start();
		});
	})
}
if (window.cordova) {
    document.addEventListener("deviceready", onDeviceReady, false);
} else {
    onDeviceReady();
}